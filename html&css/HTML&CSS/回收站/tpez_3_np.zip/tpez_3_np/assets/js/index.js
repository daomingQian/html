var toggle = document.getElementById('container');
var toggleContainer = document.getElementById('toggle-container');
var toggleNumber;

toggle.addEventListener('click', function() {
	toggleNumber = !toggleNumber;
	if (toggleNumber) {
		toggleContainer.style.clipPath = 'inset(0 0 0 50%)';
		toggleContainer.style.backgroundColor = 'dodgerblue';
	} else {
		toggleContainer.style.clipPath = 'inset(0 50% 0 0)';
		toggleContainer.style.backgroundColor = 'dodgerblue';
	}
	console.log(toggleNumber)
});
//鼠标点击 点击另外一个这个取消
$(function () {
    var collection = $(".flag");
    $.each(collection, function () {
        $(this).addClass("start");
    });
});
//单击事件
function dj(dom) {
    var collection = $(".flag");
    $.each(collection, function () {
        $(this).removeClass("end");
        $(this).addClass("start");
    });
    $(dom).removeClass("start");
    $(dom).addClass("end");
}